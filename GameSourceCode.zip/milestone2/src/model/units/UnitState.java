package model.units;

public enum UnitState {
	IDLE, RESPONDING, TREATING;
}
