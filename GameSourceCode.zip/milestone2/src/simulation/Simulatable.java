package simulation;

public interface Simulatable {
	public void cycleStep();//to be implemented in all simulatable objects
}
