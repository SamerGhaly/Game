package controller;

import java.io.IOException;

public interface GUIListener {
	public void nextCycle() throws IOException;
}
