package TCP;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	ServerSocket ss;
	Socket s;

	DataInputStream din;
	DataOutputStream dout;

	BufferedReader br;

	String str = "", str2 = "";

	public boolean opened;

	public Server() throws IOException {
		// TODO Auto-generated constructor stub
		ss = new ServerSocket(5000);
		while(true) {
			try {
				s = ss.accept();
				break;
			}catch(Exception e) {
				
			}
		}

		din = new DataInputStream(s.getInputStream());
		dout = new DataOutputStream(s.getOutputStream());

		br = new BufferedReader(new InputStreamReader(System.in));

		opened = true;
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(opened) {
					try {
						str = din.readUTF();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				//add str to the chat
			}
		}).start();

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(opened) {
					try {
						str2 = br.readLine();
						dout.writeUTF(str2);
						dout.flush();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			}
		}).start();

		din.close();
		dout.close();
		br.close();
		ss.close();
		s.close();
	}

}
